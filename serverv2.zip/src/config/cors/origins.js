const allowedOrigins = ["http://localhost:5173", "http://localhost:4173", "http://localhost:8080", "https://quizer.cycarts.com"];

module.exports = allowedOrigins;
